The order of instruments is as follows:

Clave.aif
How+1.aif
LogHit.aif
PercHit3.aif
Rainstick.aif
Roar+2.aif
Tamb.aif
Toms2.aif
Toms1.aif
UduPotHit.aif
Shaker.aif
SleighBells.aif
VoxC4.aif
Taiko.aif

